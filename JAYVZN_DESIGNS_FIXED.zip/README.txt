# JAYVZN DESIGNS — Publishable Site

This folder is ready for a static-hosting service such as Netlify.

## Customer orders + email
The order form is already configured as a Netlify Form, including image uploads.

After publishing:
1. Open your Netlify site dashboard.
2. Go to Forms and confirm `design-order` is detected.
3. Open form notifications / email notifications.
4. Add the email address where you want customer orders sent.
5. Submit a test order from the live site.

Netlify will receive the form submission and can email you the order details and uploaded files.

## Publish
The easiest route is Netlify:
1. Create/sign into a Netlify account.
2. Choose Add new project / Deploy manually (wording may vary).
3. Drag the entire `JAYVZN_Publishable` folder into the deploy area, or upload the ZIP.
4. Netlify gives you a temporary public site address.
5. Change the site name/domain in Netlify if you want a custom web address.

No server is required for the starter version.

## Add more portfolio pictures
Put new image files in `assets/`, then add another `<figure>` inside the `.gallery` section in `index.html`.

## Important
Do not publish a customer's private reference picture in your portfolio without permission.
